"""Fetch events between two dates."""

from event_store import fetch_events_between


def main() -> None:
    events = fetch_events_between(
        "2026-06-08T00:00:00Z",
        "2026-06-15T23:59:59Z",
    )

    print(f"Found {len(events)} event(s):")

    for event in events:
        print(
            f"[{event.happened_at}] "
            f"{event.description} | "
            f"confidence={event.confidence:.2f} | "
            f"change={event.change_data}"
        )


if __name__ == "__main__":
    main()
