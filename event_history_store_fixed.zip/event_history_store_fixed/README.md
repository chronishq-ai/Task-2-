# Append-Only Event History Store

This project stores every event permanently in a local SQLite database.

## Files

- `event_store.py` — database setup, `add_event()`, and `fetch_events_between()`
- `seed_events.py` — inserts 18 fictional sample events
- `demo_query.py` — demonstrates date-range retrieval
- `test_event_store.py` — verifies querying and append-only protection
- `events.db` — created automatically

## Table

| Column | Meaning |
|---|---|
| `id` | Unique event ID |
| `description` | What happened |
| `happened_at` | When it happened |
| `change_data` | JSON describing what changed |
| `confidence` | Score from 0.0 to 1.0 |
| `created_at` | When the event was inserted |

## Run in PowerShell

```powershell
python seed_events.py
python demo_query.py
python -m unittest test_event_store.py
```

## Expected test result

```text
Ran 3 tests

OK
```

## Append-only rule

There are no update or delete functions.

SQLite triggers also block direct `UPDATE` and `DELETE` statements.

## Future schema growth

New nullable columns or columns with defaults can be added later:

```sql
ALTER TABLE events ADD COLUMN source TEXT;
```

Existing rows will remain valid.
