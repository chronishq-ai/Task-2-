"""Insert fictional sample events into the database."""

from pathlib import Path

from event_store import DEFAULT_DB_PATH, add_event, initialize_database


SAMPLE_EVENTS = [
    ("User created a workspace", "2026-06-01T09:15:00Z",
     {"workspace_id": "ws-1001", "status": "created"}, 0.99),

    ("Notification preferences were detected", "2026-06-02T11:30:00Z",
     {"email_notifications": True, "push_notifications": False}, 0.88),

    ("First project was added", "2026-06-03T14:10:00Z",
     {"project_id": "prj-201", "project_count_change": 1}, 0.98),

    ("Project deadline was recorded", "2026-06-04T10:00:00Z",
     {"project_id": "prj-201", "deadline": "2026-06-18"}, 0.96),

    ("User completed onboarding", "2026-06-05T16:45:00Z",
     {"onboarding_status": "complete"}, 0.99),

    ("Weekly activity level increased", "2026-06-07T18:20:00Z",
     {"previous_level": "low", "new_level": "medium"}, 0.81),

    ("A task was marked complete", "2026-06-08T09:05:00Z",
     {"task_id": "task-301", "status": "completed"}, 0.99),

    ("A project risk was identified", "2026-06-09T13:40:00Z",
     {"project_id": "prj-201", "risk": "schedule delay"}, 0.84),

    ("Suggested reminder was accepted", "2026-06-10T08:50:00Z",
     {"reminder_id": "rem-401", "accepted": True}, 0.93),

    ("User added a second project", "2026-06-11T12:25:00Z",
     {"project_id": "prj-202", "project_count_change": 1}, 0.99),

    ("Preferred working time was inferred", "2026-06-12T19:10:00Z",
     {"preferred_period": "evening"}, 0.76),

    ("Project priority changed", "2026-06-14T15:00:00Z",
     {"project_id": "prj-202", "old_priority": "medium", "new_priority": "high"}, 0.91),

    ("A milestone was reached", "2026-06-15T10:35:00Z",
     {"project_id": "prj-201", "milestone": "prototype complete"}, 0.97),

    ("A collaboration pattern was detected", "2026-06-16T17:50:00Z",
     {"frequent_collaborator": "user-88", "interaction_count": 7}, 0.79),

    ("User postponed a task", "2026-06-18T09:45:00Z",
     {"task_id": "task-322", "new_date": "2026-06-21"}, 0.95),

    ("Weekly activity level increased again", "2026-06-20T20:15:00Z",
     {"previous_level": "medium", "new_level": "high"}, 0.86),

    ("A new project note was saved", "2026-06-22T11:05:00Z",
     {"project_id": "prj-202", "note_type": "decision"}, 0.99),

    ("A deadline risk was resolved", "2026-06-24T14:30:00Z",
     {"project_id": "prj-201", "status": "resolved"}, 0.94),
]


def seed_database(
    db_path: str | Path = DEFAULT_DB_PATH,
    reset: bool = False,
) -> None:
    db_path = Path(db_path)

    if reset and db_path.exists():
        db_path.unlink()

    initialize_database(db_path)

    for description, happened_at, change_data, confidence in SAMPLE_EVENTS:
        add_event(
            description=description,
            happened_at=happened_at,
            change_data=change_data,
            confidence=confidence,
            db_path=db_path,
        )

    print(f"Inserted {len(SAMPLE_EVENTS)} events into {db_path}")


if __name__ == "__main__":
    seed_database(reset=True)
