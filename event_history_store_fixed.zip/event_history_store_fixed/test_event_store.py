"""Tests for the append-only event store."""

import sqlite3
import tempfile
import unittest
from pathlib import Path

from event_store import add_event, fetch_events_between, initialize_database


class EventStoreTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_events.db"
        initialize_database(self.db_path)

    def tearDown(self) -> None:
        self.temp_dir.cleanup()

    def test_fetches_only_events_inside_range(self) -> None:
        add_event("Before", "2026-06-01T08:00:00Z", {}, 0.9, self.db_path)
        add_event("Inside", "2026-06-10T08:00:00Z", {"x": 1}, 0.8, self.db_path)
        add_event("After", "2026-06-20T08:00:00Z", {}, 0.7, self.db_path)

        results = fetch_events_between(
            "2026-06-09T00:00:00Z",
            "2026-06-11T00:00:00Z",
            self.db_path,
        )

        self.assertEqual(
            [event.description for event in results],
            ["Inside"],
        )

    def test_database_rejects_updates(self) -> None:
        event_id = add_event(
            "Original event",
            "2026-06-10T08:00:00Z",
            {},
            0.9,
            self.db_path,
        )

        connection = sqlite3.connect(self.db_path)
        try:
            with self.assertRaises(sqlite3.IntegrityError):
                connection.execute(
                    "UPDATE events SET description = ? WHERE id = ?",
                    ("Changed event", event_id),
                )
        finally:
            connection.close()

    def test_database_rejects_deletes(self) -> None:
        event_id = add_event(
            "Permanent event",
            "2026-06-10T08:00:00Z",
            {},
            0.9,
            self.db_path,
        )

        connection = sqlite3.connect(self.db_path)
        try:
            with self.assertRaises(sqlite3.IntegrityError):
                connection.execute(
                    "DELETE FROM events WHERE id = ?",
                    (event_id,),
                )
        finally:
            connection.close()


if __name__ == "__main__":
    unittest.main()
